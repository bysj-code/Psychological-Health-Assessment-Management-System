const base = {
    url : "http://localhost:8080/daxueshengxinlijiankangpingce/"
}
export default base
