

## Tag 标签
> **组件名：uni-tag**
> 代码块： `uTag`


用于展示1个或多个文字标签，可点击切换选中、不选中的状态 。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-tag)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 


