declare module '*/common/queue' {
  export const queueDraw: any;
  export const queueLoadImage: any;
}